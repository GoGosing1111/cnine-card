검은 제복 · 쌍우지 / 일제난사 — 2026-10-14

현재 기준: manifest.json
얼굴 각도는 사용자가 마지막에 재첨부한 user-face-angle-locked-20261014.png를 유지한다.
눈동자 방향, 검은 장발, 군인·스나이핑·탄환 아우라를 반영한 원화 v4가 현재 시안이다.
SSS 리미티드급은 연출 품질 요청으로 기록했다. 이름·코드·등급·경제 수치는 임의 등록하지 않았다.

현재 산출물
- 원화: assets/black-uniform-dual-uzi-source-art-v4-face-angle-locked.png
- 투명 전신: assets/black-uniform-dual-uzi-battle-v3-longhair.png
- 서 있는 사격 반동: assets/standing-burst-motion-v2.png (8프레임)
- 스코프·탄환 아우라: assets/scope-ballistic-aura-12f-v2.png (12프레임)
- 총구 섬광: assets/uzi-muzzle-8f-v1.png (8프레임)
- 스코프 집중 타격: assets/scope-elimination-16f-v2.png (16프레임)
- 전체 실제 생성 프롬프트: prompts/ 및 manifest.json

로컬 실행 (저장소 루트에서)
node preview/mercenary-black-uniform-dual-uzi-v1/serve.mjs
http://127.0.0.1:8847/preview/mercenary-black-uniform-dual-uzi-v1/

자산 검사/명세 갱신
node preview/mercenary-black-uniform-dual-uzi-v1/build-resources.mjs

프리뷰 번들 갱신
node preview/mercenary-black-uniform-dual-uzi-v1/build.mjs

검사
node --test preview/mercenary-black-uniform-dual-uzi-v1/qa.test.mjs

기존 V3 BattleEngine의 combatLayer/effectLayer와 PixiJS/GSAP 의존성을 사용한다.
GSAP 한 시계로 신체 프레임, 양쪽 총구, 탄도, 표적 포착과 집중 타격을 제어한다.
일시정지·시킹·0.25/0.5/1/2배속·재시작·취소와 화면 이탈 시 정리를 제공한다.
연속 사격은 시연용 20회 동시 발사로 구성했다. 게임의 실제 공격 횟수/배율은 설정하지 않았다.
피해량·HP·재화·승패·획득·도감·라이브 API는 변경하지 않는다.
새 사운드는 넣지 않았다. 사용자 시각 승인 대기이며 운영 배포 대상이 아니다.
기존 짧은 머리 이미지와 이전 시트는 제작 이력으로만 보존한다.
