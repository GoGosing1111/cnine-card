검은 제복 · 쌍우지 / 일제난사 · 양자 탄도 폭쇄 — 2026-10-14

현재 기준: manifest.json
얼굴 각도는 사용자가 마지막에 재첨부한 user-face-angle-locked-20261014.png를 유지한다.
눈동자 방향, 검은 장발, 군인·스나이핑·탄환 아우라를 반영한 원화 v4가 현재 시안이다.
SSS 리미티드급은 연출 품질 요청으로 기록했다. 이름·코드·등급·경제 수치는 임의 등록하지 않았다.

현재 산출물
- 원화: assets/black-uniform-dual-uzi-source-art-v4-face-angle-locked.png
- 투명 전신: assets/black-uniform-dual-uzi-battle-v3-longhair.png
- 서 있는 사격 반동: assets/standing-burst-motion-v2.png (8프레임)
- 스코프·탄환 아우라: assets/scope-ballistic-aura-12f-v2.png (12프레임)
- 총구 섬광: assets/uzi-muzzle-8f-v1.png (8프레임)
- 스코프 집중 타격: assets/scope-elimination-16f-v2.png (16프레임)
- 양자 탄환 수렴: assets/quantum-bullet-convergence-12f-v1.png (12프레임)
- 양자 대폭발: assets/quantum-ballistic-collapse-16f-v2.png (16프레임)
- 전체 실제 생성 프롬프트: prompts/ 및 manifest.json

최신 요청 반영
- 원형 아우라: 생성 시트에서 프레임마다 달랐던 실제 원 중심을 aura-registration.mjs에 기록했다.
  각 중심을 같은 캐릭터 로컬 좌표 (-12, -207.4)에 맞춘 뒤 그 자리에서 회전한다.
  셀 중앙 기준 회전으로 생기던 최대 50px의 원본 좌표 이동을 제거했다.
- 흰색 테두리: 현재 포즈의 알파를 보존하는 흰색 외곽과 이중 블룸을 캐릭터 뒤에 표시한다.
  모자·머리·제복·총·부츠까지 같은 포즈를 따르며 프리뷰에서 켜고 끌 수 있다.
- 광역기: '양자 탄도 폭쇄'. 적 5명의 스코프 → 쌍우지 탄환 수렴 → 양자 코어 임계 →
  은백색 대폭발·검은 충격파 → 개별 표적 연쇄 타격. 기존 일제난사는 따로 선택한다.
- 전체 72프레임: 신체 8 + 독립 효과 64. 폭발/소멸은 실제 변화하는 새 연속 원본이다.
- 폭발 v1은 셀 경계 간섭으로 미채택이다. v2의 투명한 행 여백을 정확한 텍스처 사각형으로 읽는다.
  PNG 픽셀은 수정하지 않았다. 모든 채택 프레임의 경계 알파 검사를 통과했다.
- 새 효과는 내장 ImageGen으로 제작했고 생성 입력과 수정 프롬프트를 함께 보존했다.

광역기 시각 계획 (총 7.8초)
0.00~0.95 다중 스코프 / 0.95~2.80 쌍우지 사격·수렴 / 2.80~3.25 코어 압축
3.25~6.55 대폭발·충격파·연기 / 3.65,3.83,4.01,4.19,4.37 다섯 표적 연쇄 타격
6.55~7.80 정리. 시연용 발사·타격 시각은 게임 피해량이나 확정 공격 횟수가 아니다.

로컬 실행 (저장소 루트에서)
node preview/mercenary-black-uniform-dual-uzi-v1/serve.mjs
http://127.0.0.1:8847/preview/mercenary-black-uniform-dual-uzi-v1/

자산 검사/명세 갱신
node preview/mercenary-black-uniform-dual-uzi-v1/build-resources.mjs

프리뷰 번들 갱신
node preview/mercenary-black-uniform-dual-uzi-v1/build.mjs

검사
node --test preview/mercenary-black-uniform-dual-uzi-v1/qa.test.mjs

기존 V3 BattleEngine의 combatLayer/effectLayer와 PixiJS/GSAP 의존성을 사용한다.
GSAP 한 시계로 신체 프레임, 양쪽 총구, 탄도, 표적 포착, 집중 타격과 광역기를 제어한다.
일시정지·시킹·0.25/0.5/1/2배속·재시작·취소와 화면 이탈 시 정리를 제공한다.
연속 사격은 시연용 20회 동시 발사로 구성했다. 게임의 실제 공격 횟수/배율은 설정하지 않았다.
피해량·HP·재화·승패·획득·도감·라이브 API는 변경하지 않는다.
새 사운드는 넣지 않았다. 사용자 시각 승인 대기이며 운영 배포 대상이 아니다.
기존 짧은 머리 이미지와 이전 시트는 제작 이력으로만 보존한다.

검수: 관련 회귀 6개 통과. PC 1365×1000 / 모바일 390×844에서 포착·수렴·대폭발 확인.
아우라 12개 프레임의 실제 표시 중심 좌표 동일, 포즈별 흰색 광원 일치, 1배속 종료와
0.5배속·일시정지·시킹·취소·스킬 교체 및 전장 제거 정리를 확인했다. 자세한 수치는 qa/review.json.
리소스 패키지 v2는 새 효과·현재 원화·코드·프롬프트를 담는다. 전장 실행은 기존 저장소 자산을 사용한다.
