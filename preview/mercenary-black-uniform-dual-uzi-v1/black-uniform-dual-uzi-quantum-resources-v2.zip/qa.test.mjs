import test from 'node:test';import assert from 'node:assert/strict';import {sample,shots,SKILL} from './skill.mjs';
import {QUANTUM,quantumShots} from './skill.mjs';
import {AURA_REGISTRATION,auraTransform} from './aura-registration.mjs';
test('both muzzles share each volley and hits follow release',()=>{assert.equal(shots.length,20);for(const s of shots){assert.equal(s.pair,2);assert.ok(s.at>=SKILL.release);assert.ok(s.target>=0&&s.target<3);assert.ok(sample(s.at+.01).shots.some(x=>x.at===s.at));}});
test('seeking yields the same frame state and clamps at cleanup',()=>{const a=sample(2.63);sample(4);assert.deepEqual(sample(2.63),a);assert.equal(sample(-1).time,0);const done=sample(50);assert.equal(done.time,SKILL.duration);assert.equal(done.shots.length,0);assert.equal(done.finishes.length,0);assert.equal(done.pose,0);assert.equal(done.done,true);});
test('all phases and requested continuous body poses are covered',()=>{assert.match(sample(.4).label,/포착/);assert.match(sample(1.5).label,/난사/);assert.match(sample(3.6).label,/집중/);assert.match(sample(4.7).label,/잔광/);assert.deepEqual(new Set(Array.from({length:580},(_,i)=>sample(i/100).pose)),new Set([0,1,2,3,4,5,6,7]));});
test('scope artwork centers stay fixed through frame changes and rotation',()=>{
 assert.ok(Math.max(...AURA_REGISTRATION.map(r=>r.y))-Math.min(...AURA_REGISTRATION.map(r=>r.y))>=40);
 for(let t=0;t<8;t+=.031){const r=AURA_REGISTRATION[Math.floor(t*8)%12],tr=auraTransform({registration:r,rect:{width:362,height:362}},340,t);
  const dx=(r.x-tr.anchorX*362)*tr.scale,dy=(r.y-tr.anchorY*362)*tr.scale;
  assert.ok(Math.abs(tr.x+dx*Math.cos(tr.rotation)-dy*Math.sin(tr.rotation)+12)<1e-8);
  assert.ok(Math.abs(tr.y+dx*Math.sin(tr.rotation)+dy*Math.cos(tr.rotation)+207.4)<1e-8);
  assert.ok(Math.abs(r.radius*tr.scale-103.7)<1e-8);
 }
});
test('quantum skill has five distinct contacts after the common detonation',()=>{
 assert.deepEqual(new Set(quantumShots.map(s=>s.target)),new Set([0,1,2,3,4]));
 assert.equal(QUANTUM.finish.length,5);assert.ok(QUANTUM.finish.every(t=>t>QUANTUM.detonation));
 QUANTUM.finish.forEach((t,i)=>assert.ok(sample(t+.03,'quantum').finishes.some(f=>f.target===i)));
 assert.ok(sample(2.7,'quantum').charge);assert.ok(sample(4.7,'quantum').blast);assert.equal(sample(7.8,'quantum').blast,null);
});
test('quantum backward seek and cleanup do not retain transient state',()=>{
 const before=sample(2.4,'quantum');sample(5.4,'quantum');assert.deepEqual(sample(2.4,'quantum'),before);
 const done=sample(50,'quantum');assert.equal(done.time,QUANTUM.duration);assert.equal(done.pose,0);assert.equal(done.dim,0);assert.equal(done.flash,0);assert.equal(done.shots.length,0);assert.equal(done.finishes.length,0);assert.equal(done.charge,null);assert.equal(done.blast,null);
});
